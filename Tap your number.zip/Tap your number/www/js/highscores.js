document.ready = function(){
	var highscore = document.getElementById('highscore');
	var number = localStorage.getItem('number');
	var highestScore = highscore.innerHTML;
	var highscoreArray;
	var newScore = 0;
	console.log(highestScore);
};